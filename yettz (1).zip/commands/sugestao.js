const Discord = require('discord.js');
const db = require('quick.db');
const config = require('../../config.json')

exports.run = async (client, message, args) => {

 let chx = db.get(`sugestao_${message.guild.id}`)

 if (chx === null) {
   return message.reply(`Opa, Parece que o canal de sugestao nao foi setado! digite ${config.prefix}setsugestao <3`)
 }

  let sugestão = args.splice(0).join(' ');
  if (!sugestão) {
    return message.reply("**Digite a sugestão para eu enviar**")
  }

  if (sugestão.length > 500) {
    return message.channel.send("sugestao tem que ser até 500 caracteres ")
  }

 {

  let embedsugesttion = new Discord.MessageEmbed()
  .setTitle(`sugestão de  ${message.author.username}`)
  .setDescription(`sugestão: ${sugestão}`)
  .setColor("WHITE")

    client.channels.cache.get(chx).send(embedsugesttion).then(msg => {
      msg.react(`✅`);//o bot tem que tar no servidor do emoji 
      msg.react(`❌`)
    })

    message.channel.send("✅ **sugestão enviada com sucesso!**")
 }
};
