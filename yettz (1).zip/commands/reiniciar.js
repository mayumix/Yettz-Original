module.exports = {
    name: "restartbot",
    category: "moderation",
    run: async (client, message, args) => {
        if (message.author.id !== '808487720002388018') {
            return message.channel.send(`Você não pode usar este comando!`)
        }
        await message.channel.send(`Reiniciando o bot.. `)
        process.exit();
    }
}