const Discord = require("discord.js");
exports.run = async (bot, message, args) => {
 
    message.channel.send(`${message.author}, Enviei formulário para que bug aconteceu`).then(msg => msg.delete(9000));
    let member = message.author;
    message.delete().catch();
    await message.author.createDM();
 
    let embed = new Discord.MessageEmbed()
        .setDescription(`▫| Digite Ok pra continuar`)
    message.author.send(embed)
   
 
   
    var tazer = message.author.dmChannel.createMessageCollector(a => a.author.id == message.author.id, { time: 10000 * 50, max: 1 });
    tazer.on('collect', r => {
        let nome = r.content;
        let embed2 = new Discord.MessageEmbed()
            .setDescription(`Qual é problema?`)
        message.author.send(embed2)
 
        var tazer1 = message.author.dmChannel.createMessageCollector(a => a.author.id == message.author.id, { time: 10000 * 50, max: 1 });
        tazer1.on('collect', r => {
            let serve = r.content;
            let embed3 = new Discord.MessageEmbed()
                .setDescription(`Tem certeza que acontece isso`)
            message.author.send(embed3)
 
            var tazer2 = message.author.dmChannel.createMessageCollector(a => a.author.id == message.author.id, { time: 10000 * 50, max: 1 });
            tazer2.on('collect', r => {
                let online = r.content;
                let embed4 = new Discord.MessageEmbed()
                    .setDescription(`Tem print?`)
                message.author.send(embed4)
 
                var tazer3 = message.author.dmChannel.createMessageCollector(a => a.author.id == message.author.id, { time: 10000 * 50, max: 1 });
                tazer3.on('collect', r => {
                    let clasi = r.content;
                    let embed5 = new Discord.MessageEmbed()
                        .setDescription(`Qual seu discord?`)
                    message.author.send(embed5)
 
                    var tazer4 = message.author.dmChannel.createMessageCollector(a => a.author.id == message.author.id, { time: 10000 * 50, max: 1 });
                    tazer4.on('collect', r => {
                        let fac = r.content;

                                let embed8 = new Discord.MessageEmbed()
                                    .setDescription("*Para confirmar digite ** `Confirmar`, **para cancelar digite `Cancelar`**.")
                                message.author.send(embed8)
 
                                var confirm = message.author.dmChannel.createMessageCollector(a => a.author.id == message.author.id, { time: 10000 * 50, max: 1 });
                                confirm.on('collect', r => {
                                    if (r.content.toLowerCase() == "confirmar") {
                                        let embed12 = new Discord.MessageEmbed()
                                            .setDescription(`Seu reporte foi enviado!`)
                                            message.author.send(embed12)
                                        
                      let servericon = message.author.displayAvatarURL;
                                        const form = new Discord.MessageEmbed()
                                            .setTitle('Novo bug')
                                            .addField("Discord da pessoa:", message.author.tag)
                                            .addField("Bug:", serve)
                                            .addField("Tem print?:", online)
                                            .addField("Tem certeza?", clasi)
                                            .setFooter(`cafezinho © 2021`)
                                            .setThumbnail(servericon)
                                            .setColor('RANDOM')
                                        bot.channels.cache.get('821403932155838480').send(`|| < cafezinho#3844 > ||`, form).then(async msg => {
                                            const collector = msg.createReactionCollector((r, u) => (r.emoji.name === '✔') && (u.id !== bot.user.id && u.id === message.author.id))
                                            collector.on("collect", r => {
                                                switch (r.emoji.name) {
                                                    case '✔':
                                                    let embed13 = new Discord.MessageEmbed()
                                                    .setDescription(``)
                                                        message.author.createDM().then(dm => dm.send(embed13))
                                                        break;
                                                }
                                            })
                                        })
                                    }
                                    if (r.content.toLowerCase() == "cancelar") {
                                        message.author.send({ embed: { description: "Bug cancelado." } });
                                    }
                                })
                            })
                        })
                    })
                })
            })
        }

exports.help = {
    name: 'pedidos',
    aliases: ['pedir']
}