const db = require("quick.db")

exports.run = async (bot, message, args) => {
let permissão = message.member.hasPermission("ADMINISTRATOR"); 
let prefixo = args[0]; 
if(!permissão) return message.channel.send("Você não tem permissão"); 
if(!prefixo) return message.channel.send("Você não escreveu um prefixo")
db.set(`${message.guild.id}.prefix`, args[0])

message.channel.send("**✅ | Prefixo mudado com sucesso!**")
}
