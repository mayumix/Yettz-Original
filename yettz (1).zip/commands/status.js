const Discord = require('discord.js')
exports.run = (client, message, args) => {
message.channel.send(new Discord.MessageEmbed()
.setColor('#FF0000')
.setDescription(` <:cpu:822153199850881044> CPU: **${(process.cpuUsage().system / 1024 / 1024).toFixed(2)}%**\ 
<:ram_memoria:822152755463716884> Memoria: **${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)} MB/500MB**\n<:uptime:822152645174493214> Uptime: **${require('ms')(client.uptime)}**\n<:ping:822152698736017439> Ping: ${Math.round(
      client.ws.ping
    )}ms\n \ <:js:822155996096102420> Linguagem:\ Node Js\n <:membros:822155967209799801> ${client.guilds.cache.size} Servidores\n <:membros:822155967209799801> ${client.users.cache.size} Membros
<:dono:822155939448750100> Dono: <@808487720002388018>`));
};
