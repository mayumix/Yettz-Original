const Discord = require("discord.js")

module.exports.run = async(client,message,args)=> {
  message.delete().catch(O_o => {});
  if(!message.member.hasPermission("ADMINISTRATOR")) return message.reply("Você não pode usar esse comando.")
    let user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
    let mensagem = args.splice(1).join(' ');

    if(!mensagem ) return msg.reply('| Você têm que me dar um motivo!');
    if(!user) return message.reply("❌ Mencione alguem!").then(msg => msg.delete({timeout: 5000}))

  user.send(`${mensagem}\n\nMensagem enviada por ${message.author}`)

message.channel.send(`Mensagem enviada para a DM de ${user} com sucesso!`)
}
