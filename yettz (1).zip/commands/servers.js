const discord = require('discord.js')
 
module.exports = {
    name:"servidores",
    category:"commands",
    run: async (client, message, args) => {
 
        const embed = new discord.MessageEmbed()
        .setDescription(`**Atualmente estou em ${client.guilds.cache.size} servidores **`)
        .setImage()
        .setColor('ff0000')
        message.channel.send(embed)
 
    }
}
