const Discord = require('discord.js')
const db = require('quick.db')

module.exports = async (bot, message) => {
  
  let canal = await db.get(`logs_${message.guild.id}`);

    const embed = new Discord.MessageEmbed()
      .setAuthor('Logs | Mensagem Deletada', bot.user.avatarURL)
      .setThumbnail(message.author.avatarURL)
      .setDescription(`**Usuário:** ${message.author}\n**Canal:** <#${message.channel.id}>`)
      .addField('**Mensagem:**', `\`\`\`${message.content.length < 1000 ? message.content : 'Não consegui recuperar essa mensagem pois possui mais de 1000 caracteres.'}\`\`\`\ `, false)
      .setFooter(`Id: ${message.author.id}`, message.author.avatarURL)
      .setTimestamp()
      .setColor('#ff0000')
bot.channels.cache.get(canal).send(embed)
}
